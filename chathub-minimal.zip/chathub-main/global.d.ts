declare module '*.gql'
