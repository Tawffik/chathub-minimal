// Plausible analytics disabled - no metadata sent
export const plausible = {
  enableAutoPageviews: () => {},
  trackEvent: () => {},
}

export function trackEvent(_name: string, _props?: any) {
  // no-op
}
